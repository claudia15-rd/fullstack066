const mongoose = require("mongoose");

const TareaSchema = new mongoose.Schema({  
    id: mongoose.Schema.ObjectId,
    idPanel: {
        type: mongoose.Schema.ObjectId,
        ref: "Panel"
    },
    titulo: String,
    descripcion: String,
    fecha_inicio: Date,
    fecha_fin: Date,
    estado: String,
    archivo: Buffer,
    nombre_archivo: String,
});

module.exports = mongoose.model("Tarea", TareaSchema);
