const mongoose = require("mongoose");
const Tarea = require("./Tarea");

const PanelSchema = new mongoose.Schema({ 
    id: mongoose.Schema.ObjectId,       
    titulo: String,
    descripcion: String
});

module.exports = mongoose.model("Panel", PanelSchema);
