const express = require('express');
const router = express.Router();
const panelController = require('../controllers/PanelController');
const tareaController = require('../controllers/TareasController');


router.get('/panel/:id', tareaController.homepage);
router.get('/:file', tareaController.file);
router.get('/', panelController.homepage);

module.exports = router