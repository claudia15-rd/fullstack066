const { ApolloServer } = require('apollo-server-express');
const { connectDB } = require("./config/database");
const { execute, subscribe } = require('graphql');
const express = require('express');
const http = require('http');
const { makeExecutableSchema } = require('@graphql-tools/schema');
const panelController = require('./controllers/PanelController');
var path = require('path');
const router = require('./router/router.js');
const SocketIO = require('socket.io');
const { SubscriptionServer } = require('subscriptions-transport-ws');
const tareaController = require('./controllers/TareasController');
require('dotenv').config();

const app = express();
const httpServer = http.createServer(app);
connectDB();

app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, '/views'))
app.use(express.urlencoded( { extended: true} ));
app.use(express.static(path.join(__dirname, '../', 'public')));
app.use('/', router);

const schema = makeExecutableSchema({
    typeDefs: [panelController.typedefPanel, tareaController.typedefTarea],
    resolvers: [panelController.resolversPaneles, tareaController.resolversTareas]
});

const subscriptionServer = SubscriptionServer.create(
    { schema, execute, subscribe },
    { server: httpServer, path: '/graphql'}
);

async function startApolloServer() {
    const apolloServer = new ApolloServer({
        schema,
        plugins: [
            {
                async serverWillStart(){
                    return {
                        async drainServer(){
                            subscriptionServer.close()
                        }
                    }
                }
            }
        ]
    })

    await apolloServer.start();

    apolloServer.applyMiddleware({ app });
}

startApolloServer();

httpServer.listen(process.env.PORT, () => {
    console.log(`http://localhost:${process.env.PORT}`);
});

const io = SocketIO(httpServer);

io.sockets.on('connection', function(socket) {
    socket.join("_room" + socket.handshake.query.room_id);
    console.log("new connection", socket.id);    
    panelController.PanelSocket(io, socket);
    tareaController.TareaSocket(io, socket);
});