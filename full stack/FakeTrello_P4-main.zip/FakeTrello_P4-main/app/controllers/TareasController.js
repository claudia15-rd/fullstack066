const { gql } = require('apollo-server-express');
const Tarea = require('../models/Tarea');
const { writeFile } = require("fs");
const pubsub = require('../pubsub.js');
var path = require('path');

exports.homepage = async(req, res) => {        
    res.render('pages/panel');       
}

exports.file = async(req,res) => {
    console.log(__dirname)
    console.log(req.url)
    res.sendFile(path.join(__dirname, '../', '../', '/files', req.url));      
}

const typedefTarea = gql`
    scalar Date

    type Tarea {
        id: ID! 
        idPanel: ID!
        titulo: String
        descripcion: String  
        fecha_inicio: Date
        fecha_fin: Date    
        estado: String
        archivo: String
        nombre_archivo: String
    }

    input TareaInput{
        idPanel: String!
        titulo: String
        descripcion: String
        fecha_inicio: Date
        fecha_fin: Date
        estado: String
        archivo: String
        nombre_archivo: String
    }

    type Query {        
        getAllTareas: [Tarea]
        getTareasByPanel(idPanel: ID): [Tarea]        
        getTarea(id: ID): Tarea        
    }

    type Mutation {        
        createTarea(tarea: TareaInput): Tarea        
        updateTarea(id: String!, tarea: TareaInput): Tarea        
        deleteTarea(id: String!): String                
    }
    type Subscription {
        moveTarea: Tarea
    }
`;

const resolversTareas = {
    Query: {
        async getAllTareas() {
            const tareas = await Tarea.find();
            return tareas
        },
        async getTareasByPanel(_, {idPanel}) {
            const tareas = await Tarea.find({idPanel});
            return tareas;
        },
        async getTarea(_, {id}) {
            const tarea = await Tarea.findById(id)
            return tarea
        },
    },
    Mutation: {
        async createTarea(_, args) {
            const {idPanel, titulo, descripcion, fecha_inicio, fecha_fin, estado, archivo, nombre_archivo} = args.tarea
            const newTarea = new Tarea({idPanel, titulo, descripcion, fecha_inicio, fecha_fin, estado, archivo, nombre_archivo})                                                                                        
            newTarea.id = newTarea._id
            await newTarea.save()                                 
            return newTarea
        },
        async updateTarea(_, {tarea, id}){
            const tareaUpdated = await Tarea.findByIdAndUpdate(id, {
            $set: tarea  
            }, {new: true}) 
            pubsub.publish('TAREA_MOVED', {
                moveTarea: {
                    id, 
                    estado: tarea.estado
                }
            });
            return tareaUpdated
        },
        async deleteTarea(_, {id}) {
            await Tarea.findByIdAndDelete(id)
            return "Tarea eliminada"
        },                        
    },
    Subscription: {
        moveTarea: {
            subscribe: () => pubsub.asyncIterator('TAREA_MOVED')
        }
    }
}

module.exports.TareaSocket = (io, socket) => {     
    socket.on('get:tareas', async (data) => {
        const idPanel = data.tarea.idPanel;        
        const tareas = await resolversTareas.Query.getTareasByPanel(null, {idPanel});           
        socket.emit('get:tareas', tareas)        
    })        
    socket.on('create:tarea', async (data) => {                
        const tarea = await resolversTareas.Mutation.createTarea(null, data);                
        saveFile(tarea);        
        io.sockets.emit(`${tarea.idPanel}-create:tarea`, tarea);                   
    })
    socket.on('update:tarea', async (data) => {   
        const id = data.tarea.id;
        const tarea = data.tarea;            
        const upd_tarea = await resolversTareas.Mutation.updateTarea(null, {tarea, id});  
        saveFile(upd_tarea); 
        resolversTareas.Subscription.moveTarea;  
        io.sockets.emit(`${upd_tarea.idPanel}-update:tarea`, upd_tarea);        
    })
    socket.on('delete:tarea', (data) => { 
        const id = data.tarea.id;       
        resolversTareas.Mutation.deleteTarea(null, {id})
        io.sockets.emit(`${data.tarea.idPanel}-delete:tarea`, data.tarea);
    })    
}

function saveFile(tarea){    
    if(tarea.archivo){
        const file = tarea.archivo;
        const file_path = './files/'+ tarea.id + '_' + tarea.nombre_archivo;

        writeFile(file_path, file, (err) => {
            console.log({ message: err ? "failure" : "success" });
        }); 
    }
}

exports.typedefTarea = typedefTarea;
exports.resolversTareas = resolversTareas;