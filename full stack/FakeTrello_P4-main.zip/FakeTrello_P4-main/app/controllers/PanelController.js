const { gql } = require('apollo-server-express');
const Panel = require('../models/Panel');

exports.homepage = async(req, res) => { 
    res.render('pages/home');    
}

const typedefPanel = gql`
    type Panel {
        id: ID!
        titulo: String
        descripcion: String        
    }
    
    input PanelInput{
        titulo: String
        descripcion: String
    }

    type Query {                
        getAllPaneles: [Panel]        
        getPanel(id: ID): Panel       
    }

    type Mutation {
        createPanel(panel: PanelInput): Panel                
        updatePanel(id: ID!, panel: PanelInput): Panel     
        deletePanel(id: ID!): String
    }
`;
   
const resolversPaneles = {
    Query: {
        async getAllPaneles(){
            const paneles = await Panel.find();
            return paneles;
        },
        async getPanel(_, {id}) {
            const panel = await Panel.findById(id)
            return panel
        }  
    },
    Mutation: {
        async createPanel(_, args) {
            const {titulo, descripcion} = args.panel
            const newPanel = new Panel({titulo, descripcion})
            newPanel.id = newPanel._id
            await newPanel.save()
            return newPanel
        },
        async updatePanel(_, {panel, id}){            
            const panelUpdated = await Panel.findByIdAndUpdate(id, {
                $set: panel
            }, {new: true})
            return panelUpdated
        },        
        async deletePanel(_, {id}){
            await Panel.findByIdAndDelete(id)
            return "Panel eliminado"
        },        

    }
}

module.exports.PanelSocket = async (io, socket) => {           
    io.sockets.emit('get:paneles', await resolversPaneles.Query.getAllPaneles())
    
    socket.on('create:panel', async (data) => {         
        const panel = await resolversPaneles.Mutation.createPanel(null, data);     
        io.sockets.emit('create:panel', panel); 
    })

    socket.on('update:panel', async (data) => { 
        const id = data.panel.id;
        const panel = data.panel
        const upd_panel = await resolversPaneles.Mutation.updatePanel(null, {panel, id});              
        io.sockets.emit('update:panel', upd_panel);        
    })
    
    socket.on('delete:panel', (data) => {   
        const id = data.panel.id
        resolversPaneles.Mutation.deletePanel(null, {id});
        io.sockets.emit('delete:panel', data.panel);
    })    
}


exports.typedefPanel = typedefPanel;
exports.resolversPaneles = resolversPaneles;