const { connect } = require('mongoose');
require('dotenv').config();

const connectDB = async () => {
    try {
        await connect(process.env.DB_HOST);        
        console.log("MongoDB connected");
    }
    catch (error) {
        console.error(error);
    }
};

module.exports = { connectDB };
