# FakeTrello

Kanban board app that is similar to Trello

## Installation

1. Download source code
```
git clone https://github.com/Alex-code-01/FakeTrello_P4
```
2. Install dependencies
```
cd FakeTrello_P4
npm install
```

3. Set the environment parameters

    3.1 Create .env file
    ```
    touch .env
    ```

    3.2 Set the necesary values in the .env file
    ```
    PORT=port_number

    DB_HOST=mongodb_atlas_host
    ```

4. Run project
```
npm start
```

## Product 1

Interface design with:
- HTML
- CSS 
- Bootstrap
- Drag and Drop API

## Product 2 

Serving data with GraphQL and MongoDB

- MongoDB Atlas
- Fetch API
- GraphQL: queries (read data)
- CodeSandbox

## Product 3

Inserting, updating and deleting data

- Socket.io
- GraphQL: mutations (create, update and delete data)
- CodeSandbox

## Product 4

Working collaboratively in real time

- Socket.io
- GraphQL: subscriptions
- CodeSandbox
