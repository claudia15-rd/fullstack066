const container_paneles = document.getElementById("paneles");
const add_panel_btn = document.getElementById("add-panel");
const upd_panel_btn = document.getElementById("upd-panel");
const form = document.getElementById("form");
add_panel_btn.addEventListener("click", createPanel);

const socket = io();

socket.on('get:paneles', function(data) {
    container_paneles.innerHTML = "";    
    for (var panel=0; panel<data.length; panel++){
        createHTMLPanel(data[panel]);
    }
})

socket.on('create:panel', function(panel) {        
    createHTMLPanel(panel);
    alertAction("El panel", "agregado");
})

socket.on('update:panel', function(panel) {        
    updateHTMLPanel(panel);
    alertAction("El panel", "modificado");
})

socket.on('delete:panel', function(panel){        
    deleteHTMLPanel(panel.id);
    alertAction("El panel", "eliminado");
})

function createPanel(){    
    const panel = getPanelfromForm();  
    
    socket.emit('create:panel', {
        panel       
    });  
}

function updatePanel(id) {           
    /* Get new values from form */
    var panel = getPanelfromForm();
    panel.id = id;
    socket.emit('update:panel', {
        id,
        panel      
    });    
}

function deletePanel(id){         
    socket.emit('delete:panel', {
        panel: {id}        
    });     
}

function getPanelfromForm(){
    const titulo = document.getElementById("title").value;
    const descripcion = document.getElementById("description").value;
    return {titulo, descripcion}
}

function modalAddPanel(){
    clearLabels();
    changeModalTitle(document.getElementById("modalTitle"), "Agregar", "panel");
    add_panel_btn.style.display="block";
    upd_panel_btn.style.display="none";

}

function modalUpdatePanel(element){    
    changeModalTitle(document.getElementById("modalTitle"), "Modificar", "panel")           

    /* Change add btn to update btn */
    add_panel_btn.style.display="none";
    upd_panel_btn.style.display="block";      
    upd_panel_btn.setAttribute("onclick", "updatePanel('" + element.parentElement.closest(".col-4").id + "')");

    /* Fill the form with the panel values */
    const dash_body = element.parentElement;
    document.getElementById("title").value=dash_body.children[0].children[0].textContent;
    document.getElementById("description").value=dash_body.children[1].textContent;
}

function modalDeletePanel(element){
    const id = element.closest(".col-4").id;    
    document.getElementById("DeleteBtn").setAttribute("onclick", `deletePanel('${id}')`);    
}

function createHTMLPanel(panel){    
    var html_panel = `<div id="${String(panel.id)}" class="col-4 overflow-auto">
                        <div class="card" style="width: 18rem;">
                            <img class="card-img-top" src="../assets/media/images/javascript.png" alt="Card image cap">
                            <div class="card-body">
                                <h5 class="card-title">
                                    <a href="/panel/${String(panel.id)}" class="title-link">${panel.titulo}</a>
                                </h5>
                                <p class="card-text">${panel.descripcion}</p>
                                <btn type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#AddUpdPanel" onclick="modalUpdatePanel(this)">Modificar</btn>
                                <btn type="button" class="btn btn-danger btn-delete" data-bs-toggle="modal" data-bs-target="#DeletePanel" onclick="modalDeletePanel(this)">Eliminar</btn>
                            </div>
                        </div>
                    </div>`;
    clearLabels();
    container_paneles.innerHTML += html_panel;
}

function updateHTMLPanel(panel){
    document.querySelector(`[id='${panel.id}'] [class='title-link']`).textContent=panel.titulo;
    document.querySelector(`[id='${panel.id}'] [class='card-text']`).textContent=panel.descripcion;
}

function deleteHTMLPanel(id){        
    document.getElementById(id).remove();
}
