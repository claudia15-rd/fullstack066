const alert_action = document.getElementById("alert-action")
alert_action.innerHTML = "";

function deleteChilds(element){
    while(element.firstChild){
        element.removeChild(element.lastChild);
    }
}

function changeModalTitle(element, action, entity){
    deleteChilds(element);
    element.appendChild(document.createTextNode(action + " " + entity));
}

function getTextContent(element){
    return element.textContent;
}

function formatDateYtoD(input) {
    var datePart = input.match(/\d+/g)
    var year = datePart[0]
    var month = datePart[1], day = datePart[2];
    return day+'/'+month+'/'+year;
}

function formatDateDtoY(input) {
    var datePart = input.match(/\d+/g),
    year = datePart[2]
    month = datePart[1], day = datePart[0];
  
    return year+'-'+month+'-'+day;
}

function clearLabels(){
    document.getElementById("form").reset();
}

function alertAction(element, action){
    document.getElementById("alert-action").innerHTML = `
        <div class="alert alert-success" role="alert">
                ${element} ha sido ${action}
        </div>
    `
}