var forms = document.querySelectorAll('.needs-validation')
        
Array.prototype.slice.call(forms)
.forEach(function (form) {
	form.addEventListener('click', function (event) {
	if (!form.checkValidity()) {
		event.preventDefault()
		event.stopPropagation()
		document.getElementById("add-panel").disabled=true;		
		document.getElementById("upd-panel").disabled=true;
		
	}
	else {
		document.getElementById("add-panel").disabled=false;		
		document.getElementById("upd-panel").disabled=false;
	}

	form.classList.add('was-validated')
	}, true)
})