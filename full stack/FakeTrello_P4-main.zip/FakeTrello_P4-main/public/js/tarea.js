const todo_pannel = document.getElementById("Todo");
const progress_pannel = document.getElementById("Progress");
const finalized_pannel = document.getElementById("Finalized");
const add_button = document.getElementById("add-tarea");
const upd_button = document.getElementById("update-tarea");

add_button.addEventListener("click", createTarea);

const url = window.location.pathname;
const idPanel = url.substring(url.lastIndexOf('/')+1);
console.log(idPanel)

const socket = io();

socket.on('get:tareas', function (data) {    
    todo_pannel.innerHTML="";
    progress_pannel.innerHTML="";
    finalized_pannel.innerHTML="";
    for (var tarea=0; tarea<data.length; tarea ++){
        createHTMLTarea(data[tarea]);
    }    
})

socket.on(`${idPanel}-create:tarea`, function(tarea) {    
    createHTMLTarea(tarea);
    alertAction("La tarea", "agregada");
})

socket.on(`${idPanel}-update:tarea`, function(tarea) {       
    updateHTMLTarea(tarea);
    alertAction("La tarea", "modificada");
})

socket.on(`${idPanel}-delete:tarea`, function(tarea){     
    deleteHTMLTarea(tarea.id);
    alertAction("La tarea", "eliminada");
})

socket.emit('get:tareas', {    
    tarea: {idPanel}
});

function createTarea(){        
    var tarea = getTareafromForm();
    tarea.idPanel=idPanel;
    tarea.estado="Todo";    

    socket.emit('create:tarea', {
        tarea             
    });    
}

function updateTarea(id){           
    /* Get new values from form */
    var tarea = getTareafromForm();
    tarea.id = id;

    socket.emit('update:tarea', {
        id,
        tarea
    });    
}

function deleteTarea(id){
    socket.emit('delete:tarea', {
        tarea: {id, idPanel}
    });    
}

function getTareafromForm(){
    const titulo = document.getElementById("title").value;
    const descripcion = document.getElementById("description").value;
    const fecha_inicio = document.getElementById("startdate").value;    
    const fecha_fin = document.getElementById("deadline").value;
    const archivo = document.getElementById("file").files.item(0);
    var nombre_archivo = null;
    if (archivo != null){
        nombre_archivo = archivo.name;
    }
    return {titulo, descripcion, fecha_inicio, fecha_fin, archivo, nombre_archivo}
}

function modalAddTarea(){    
    clearLabels();
    changeModalTitle(document.getElementById("modalTitle"), "Agregar", "tarea");            
    add_button.style.display="block";
    upd_button.style.display="none";
}

function modalUpdateTarea(element){    
    changeModalTitle(document.getElementById("modalTitle"), "Modificar", "tarea");     

    /*Change add btn to update btn*/
    add_button.style.display="none";
    upd_button.style.display="block";
    upd_button.setAttribute("onclick", "updateTarea('" + element.parentElement.closest(".card").id +"')");

    /*Fill the form with tarea values*/
    const card_body = element.parentElement; 
    document.getElementById("title").value=getTextContent(card_body.children[0]);
    document.getElementById("description").value=getTextContent(card_body.children[1]);
    document.getElementById("startdate").value=formatDateDtoY(getTextContent(card_body.children[2].children[0]));            
    document.getElementById("deadline").value=formatDateDtoY(getTextContent(card_body.children[2].children[1]));            
}

function modalDeleteTarea(element){
    const id = element.closest(".card").id;
    console.log(id);
    document.getElementById("DeleteBtn").setAttribute("onclick", `deleteTarea('${id}')`);
}

function createHTMLTarea(tarea){
    var archivo_html = "";
    if(tarea.archivo != null){
        archivo_html=`<a href="/${tarea.id}_${tarea.nombre_archivo}">
                        <i class="bi bi-file-pdf"></i>
                        <p class='file-name' style="display: inline">${tarea.nombre_archivo}</p>
                        <br>
                        <br>
                    </a>`
    }
    var html_tarea = `<div id="${String(tarea.id)}" class="card mb-3" draggable="true" ondragstart="drag(event)">
                        <div class="row g-0">
                            <div class="col-md-12">
                                <div class="card-body">
                                    <h5 class="card-title">${tarea.titulo}</h5>
                                    <p class="card-description card-text">${tarea.descripcion}</p>
                                    <p class="card-text">
                                        <small class="startdate card-deadline text-muted">${formatDateYtoD(tarea.fecha_inicio)} - </small>
                                        <small class="deadline card-deadline text-muted">${formatDateYtoD(tarea.fecha_fin)}</small>
                                    </p>
                                    ${archivo_html}
                                    <btn type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#AddUpdTarea" onclick="modalUpdateTarea(this)">Modificar</btn>
                                    <btn type="button" class="btn btn-danger btn-delete" data-bs-toggle="modal" data-bs-target="#DeleteTarea" onclick="modalDeleteTarea(this)">Eliminar</btn>
                                </div>
                            </div>
                        </div>
                    </div>`        
    if (tarea.estado == "Todo"){
        todo_pannel.innerHTML+=html_tarea;
    }
    else if (tarea.estado == "Progress") {
        progress_pannel.innerHTML+=html_tarea;
        
    } else if (tarea.estado == "Finalized"){
        finalized_pannel.innerHTML+=html_tarea;
    }         
    clearLabels();
}

function updateHTMLTarea(tarea){
    document.querySelector(`[id='${tarea.id}'] [class='card-title']`).textContent=tarea.titulo;
    document.querySelector(`[id='${tarea.id}'] [class='card-description card-text']`).textContent=tarea.descripcion;
    document.querySelector(`[id='${tarea.id}'] [class='startdate card-deadline text-muted']`).textContent=formatDateYtoD(tarea.fecha_inicio) + " - ";
    document.querySelector(`[id='${tarea.id}'] [class='deadline card-deadline text-muted']`).textContent=formatDateYtoD(tarea.fecha_fin);
    if (tarea.archivo != null) {
        document.querySelector(`[id='${tarea.id}'] [class='file-name']`).textContent=tarea.nombre_archivo;
    }  
    $(`#${tarea.id}`).appendTo(`#${tarea.estado}`)
}

function deleteHTMLTarea(id){
    console.log(document.getElementById(id))
    document.getElementById(id).remove();
}
