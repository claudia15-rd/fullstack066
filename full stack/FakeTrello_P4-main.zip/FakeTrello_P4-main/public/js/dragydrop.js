function allowDrop(ev) {
    ev.preventDefault();
}

function drag(ev) {
    ev.dataTransfer.setData("text", ev.target.id);
}

function drop(ev) {
    ev.preventDefault();
    var id = ev.dataTransfer.getData("text");
    var estado = ev.target.id;
    ev.target.appendChild(document.getElementById(id));
    console.log(id, estado);

    socket.emit('update:tarea', {
        id,
        tarea: {
            id, 
            idPanel,
            estado
        }
    });
}