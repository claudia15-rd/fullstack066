var forms = document.querySelectorAll('.needs-validation')
        
Array.prototype.slice.call(forms)
.forEach(function (form) {
	form.addEventListener('click', function (event) {
	if (!form.checkValidity()) {
		event.preventDefault()
		event.stopPropagation()
		document.getElementById("add-tarea").disabled=true;
        document.getElementById("update-tarea").disabled=true;
		
	}
	else {
		document.getElementById("add-tarea").disabled=false;
        document.getElementById("update-tarea").disabled=false;
	}

	form.classList.add('was-validated')
	}, false)
})